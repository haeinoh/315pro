//convert.h

#ifndef __CONVERT_H__
#define __CONVERT_H__

void convert_to_postfix(char value[]);

#endif
